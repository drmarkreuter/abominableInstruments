Kit Lyre by Mark Reuter

Welcome to my SFZ instrument of a sampled Lyre built from an inexpensive kit at the start of the 2020 Christmas holiday. The patches include plucked strings, flicked strings (slightly harder sound), bowed lyre (bowed with a pencil), and 3 'prepared' lyre patches (paper 'mute', paperclip, elastic band 'mute'). Patches are in SFZ format.

Kind regards, Mark

Lyre kit build: https://youtu.be/0oUgwCK3Aoc
Lyre sampling VLOG: https://youtu.be/X5XmPxvPlEA

