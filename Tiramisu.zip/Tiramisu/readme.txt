Welcome to my sample instrument. There are Sfz and DecentSampler instruments here, both in the instruments folder. Samples are in the sampled folder. If you alter the directoy structure, the instruments might not work. 

Cheers, Mak [abominable May 2023]

https://www.instagram.com/abominablemusic/
